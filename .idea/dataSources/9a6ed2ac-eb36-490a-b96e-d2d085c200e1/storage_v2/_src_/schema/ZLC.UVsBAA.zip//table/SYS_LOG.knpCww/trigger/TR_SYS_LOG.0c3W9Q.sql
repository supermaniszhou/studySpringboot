CREATE TRIGGER TR_SYS_LOG
  BEFORE INSERT
  ON SYS_LOG
  FOR EACH ROW
  declare tempnum number; begin select SEQ_SYS_LOG.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

