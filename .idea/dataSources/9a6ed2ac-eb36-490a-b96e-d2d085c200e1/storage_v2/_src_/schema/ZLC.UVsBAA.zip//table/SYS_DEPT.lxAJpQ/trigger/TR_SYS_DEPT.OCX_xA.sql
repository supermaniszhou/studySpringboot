CREATE TRIGGER TR_SYS_DEPT
  BEFORE INSERT
  ON SYS_DEPT
  FOR EACH ROW
  declare tempnum number; begin select SEQ_sys_dept.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

