CREATE TRIGGER TR_SYS_ROLE
  BEFORE INSERT
  ON SYS_ROLE
  FOR EACH ROW
  declare tempnum number; begin select SEQ_SYS_ROLE.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

