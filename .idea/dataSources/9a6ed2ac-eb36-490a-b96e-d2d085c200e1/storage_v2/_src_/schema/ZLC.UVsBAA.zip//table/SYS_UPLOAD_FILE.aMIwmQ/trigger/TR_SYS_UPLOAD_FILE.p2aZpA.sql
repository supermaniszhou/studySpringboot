CREATE TRIGGER TR_SYS_UPLOAD_FILE
  BEFORE INSERT
  ON SYS_UPLOAD_FILE
  FOR EACH ROW
  declare tempnum number; begin select SEQ_SYS_UPLOAD_FILE.nextval into tempnum from dual; :new.ID :=tempnum; end;
/

